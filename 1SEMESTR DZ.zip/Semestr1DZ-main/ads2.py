a = str(input())
print(a[-1] + a[1: len(a)-1] + a[0])on=[1,-1]












